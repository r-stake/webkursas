# Malex – Business Consulting Agency Figma Template
# https://store.adveits.com/item/malex-business-consulting-agency-figma-template/changelog/

## Changelog list:

### Version 1.1.0
New:    Service inside page added
New:    About Us page added
New:    Card meta for news inside page added
New:    Title clone for news, news inside, 404, search results pages added
Update: Testimonials section
Update: Tags widget
Change: Menu items
Change: Paragraphs color

### Version 1.0.0
- Initial release
