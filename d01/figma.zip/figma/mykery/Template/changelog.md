# Mykery - Beauty Salon Figma Template
# https://store.adveits.com/item/mykery-beauty-salon-figma-template/changelog/

## Changelog list:

### Version 1.1.0
Update: Text styles and components

### Version 1.0.0
- Initial release
